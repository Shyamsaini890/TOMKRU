import Link from "next/link";
import React from "react";
const Navbar = () => {
  return (
    <div className="text-white">
      <div className="flex justify-between sm:px-28 bg-black py-2 text-sm lg:text-lg">
        <p>(GMT+5.5) 19:14:25</p>
        <div className="flex gap-5">
          <a href="#">24*7 Support</a>
          <a href="#">Facebook</a>
          <a href="#">Email</a>
        </div>
      </div>
      <div className="flex justify-between sm:px-36 px-10  sm:py-2 bg-[#191E32] text-xl">
        <h1 className="font-extrabold text-sm lg:text-lg">TOMKRU</h1>
        <Link href={"/login"} className="font-bold text-sm lg:text-lg ">
          LOGIN
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
