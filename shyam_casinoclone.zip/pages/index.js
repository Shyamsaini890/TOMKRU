// import Faq from "@/components/Faq";
import Home from "@/components/Home";
import React from "react";

const Index = () => {
  return (
    <>
      <Home />
      {/* <Faq /> */}
    </>
  );
};

export default Index;
